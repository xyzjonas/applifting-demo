from aggregator_connector.client import RemoteClient


async def loop():
    client = RemoteClient()
